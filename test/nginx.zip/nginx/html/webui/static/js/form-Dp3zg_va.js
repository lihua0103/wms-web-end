import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-DIVPqdyM.js";import"./index-BW4MclmA.js";export{m as default};
