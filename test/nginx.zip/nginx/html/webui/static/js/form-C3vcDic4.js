import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-_F7yjq8T.js";import"./index-BW4MclmA.js";export{m as default};
