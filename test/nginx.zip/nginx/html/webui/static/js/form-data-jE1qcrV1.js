import{_ as m}from"./form-data.vue_vue_type_script_setup_true_lang-hiVNlhvU.js";import"./index-BW4MclmA.js";export{m as default};
