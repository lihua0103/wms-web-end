import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-Cs4H_fk_.js";import"./index-BWMUMD6U.js";import"./wms-MO6Rhhyk.js";export{o as default};
