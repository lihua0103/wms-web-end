import{_ as m}from"./gen-form.vue_vue_type_script_setup_true_lang-B3YWv7pt.js";import"./index-BW4MclmA.js";export{m as default};
