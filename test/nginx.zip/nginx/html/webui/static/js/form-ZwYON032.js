import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-Qn1-7dop.js";import"./index-BWMUMD6U.js";export{m as default};
