import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-D1-SXqrL.js";import"./wms-MO6Rhhyk.js";import"./index-BWMUMD6U.js";export{o as default};
