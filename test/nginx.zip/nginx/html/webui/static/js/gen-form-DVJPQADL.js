import{_ as m}from"./gen-form.vue_vue_type_script_setup_true_lang-Cji4c1E2.js";import"./index-BWMUMD6U.js";export{m as default};
