import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-5qd6na2c.js";import"./index-BWMUMD6U.js";export{m as default};
