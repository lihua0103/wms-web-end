import{_ as m}from"./form-data.vue_vue_type_script_setup_true_lang-BI-dtNFt.js";import"./index-BWMUMD6U.js";export{m as default};
