import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-Dt0EvYVY.js";import"./index-BW4MclmA.js";import"./wms-CQds5TX4.js";export{o as default};
