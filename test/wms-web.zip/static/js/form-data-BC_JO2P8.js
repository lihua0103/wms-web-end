import{_ as m}from"./form-data.vue_vue_type_script_setup_true_lang-TvhkUd82.js";import"./index-BJMWv0qT.js";export{m as default};
