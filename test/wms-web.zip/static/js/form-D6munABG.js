import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-Dr6zUhLf.js";import"./index-BJMWv0qT.js";export{m as default};
