import{_ as m}from"./gen-form.vue_vue_type_script_setup_true_lang-CaNeNyF8.js";import"./index-BJMWv0qT.js";export{m as default};
